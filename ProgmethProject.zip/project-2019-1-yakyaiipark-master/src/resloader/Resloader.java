package resloader;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.text.Font;
import view.GameSetting;

public class Resloader {
	
	//menu interface
	public static Image bgMenuImg;
	public static ImageView logoImg;
	
	//buttons
	public static Image buttonFree;
	public static Image buttonPressed;
	public static Font buttonFont;
	
	//subscene
	public static Image subSceneBg;
	
	//playscene
	public static Image playSceneBg1;
	public static Image playSceneBg2;
	
	//male
	public static ImageView male1;
	public static ImageView male2;
	public static ImageView malejump;
	public static ImageView maleslide;
	
	//female
	public static ImageView female1;
	public static ImageView female2;
	public static ImageView femalejump;
	public static ImageView femaleslide;
	
	//bee
	public static Image bee1;
	public static Image bee2;
	
	//pig
	public static Image pig1;
	public static Image pig2;
	
	//fox
	public static Image fox1;
	public static Image fox2;
	
	//Gem
	public static Image appleGem;
	public static Image bananaGem;
	public static Image swordGem;
	
	//sound
	public static AudioClip jumpSound;
	public static AudioClip slideSound;
	public static AudioClip gemSound;
	public static AudioClip lose;
	public static MediaPlayer backgroundGameSound;
	public static AudioClip deadSoundMale;
	public static AudioClip deadSoundFemale;
	
	
	//health
	public static Image health100;
	public static Image health50;
	public static Image health20;
	public static Image health0;
	public static Image health90;
	public static Image health80;
	public static Image health70;
	public static Image health60;
	public static Image health40;
	public static Image health30;
	public static Image health10;
	
	public static void Load() {
		//menu interface
		bgMenuImg = new Image(ClassLoader.getSystemResource("bgMenuImg.png").toString(), 
				GameSetting.GAME_WIDTH,GameSetting.GAME_HEIGHT, false, true);
		logoImg = new ImageView(ClassLoader.getSystemResource("logoImg.png").toString());
		
		//buttons
		buttonFree = new Image(ClassLoader.getSystemResource("buttonFree.png").toString(), 
				200,50, true, true);
		buttonPressed = new Image(ClassLoader.getSystemResource("buttonPressed.png").toString(), 
				200,50, true, true);
		buttonFont =  new Font(ClassLoader.getSystemResource("kenvector_future.ttf").toString(), 18);
		
		//subscene
		subSceneBg = new Image(ClassLoader.getSystemResource("HowToPlaySubSceneBg.png").toString(),550, 400, false, true);
		
		//playscene
		playSceneBg1 = new Image(ClassLoader.getSystemResource("bg1.png").toString());
		playSceneBg2 = new Image(ClassLoader.getSystemResource("bg2.png").toString());
		
		//male
		male1 = new ImageView(ClassLoader.getSystemResource("male_run1.png").toString());
		male2 = new ImageView(ClassLoader.getSystemResource("male_run2.png").toString());
		malejump = new ImageView(ClassLoader.getSystemResource("male_jump.png").toString());
		maleslide = new ImageView(ClassLoader.getSystemResource("male_slide.png").toString());
		
		//female
		female1 = new ImageView(ClassLoader.getSystemResource("female_run1.png").toString());
		female2 = new ImageView(ClassLoader.getSystemResource("female_run2.png").toString());
		femalejump = new ImageView(ClassLoader.getSystemResource("female_jump.png").toString());
		femaleslide = new ImageView(ClassLoader.getSystemResource("female_slide.png").toString());
		
		//bee
		bee1 = new Image(ClassLoader.getSystemResource("bee1.png").toString());
		bee2 = new Image(ClassLoader.getSystemResource("bee2.png").toString());
		
		//pig
		pig1 = new Image(ClassLoader.getSystemResource("pig1.png").toString());
		pig2 = new Image(ClassLoader.getSystemResource("pig2.png").toString());
		
		//fox
		fox1 = new Image(ClassLoader.getSystemResource("fox1.png").toString());
		fox2 = new Image(ClassLoader.getSystemResource("fox2.png").toString());
		
		//Gem
		appleGem = new Image(ClassLoader.getSystemResource("apple.png").toString());
		bananaGem = new Image(ClassLoader.getSystemResource("banana.png").toString());
		swordGem = new Image(ClassLoader.getSystemResource("sword_silver.png").toString());
		
		backgroundGameSound = new MediaPlayer(
				new Media(ClassLoader.getSystemResource("backgroundSound.mp3").toString()));
		
		jumpSound = new AudioClip(ClassLoader.getSystemResource("jump.mp3").toString());
		slideSound = new AudioClip(ClassLoader.getSystemResource("slide.mp3").toString());
		gemSound = new AudioClip(ClassLoader.getSystemResource("hitgem.mp3").toString());
		
		deadSoundMale = new AudioClip(ClassLoader.getSystemResource("hitanimal.mp3").toString());
		deadSoundFemale = new AudioClip(ClassLoader.getSystemResource("hitanimal.mp3").toString());
		

		lose = new AudioClip(ClassLoader.getSystemResource("gameover.mp3").toString());
		
		//health
		health100 = new Image(ClassLoader.getSystemResource("100.png").toString());
		health50 = new Image(ClassLoader.getSystemResource("50.png").toString());
		health20 = new Image(ClassLoader.getSystemResource("20.png").toString());
		health0 = new Image(ClassLoader.getSystemResource("0.png").toString());
		health90 = new Image(ClassLoader.getSystemResource("90.png").toString());
		health80 = new Image(ClassLoader.getSystemResource("80.png").toString());
		health70 = new Image(ClassLoader.getSystemResource("70.png").toString());
		health60 = new Image(ClassLoader.getSystemResource("60.png").toString());
		health40 = new Image(ClassLoader.getSystemResource("40.png").toString());
		health30 = new Image(ClassLoader.getSystemResource("30.png").toString());
		health10 = new Image(ClassLoader.getSystemResource("10.png").toString());
	}
}
