package entity;

import entity.base.Entity;
import entity.base.Hitable;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.image.ImageView;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;
import resloader.Resloader;
import ui.CharacterSelectionSubscene;
import view.GamePlay;

public class Male extends Entity implements Hitable{

	public static Timeline MALE_ANI;
	public static Timeline JUMP_ANI;
	public static Timeline SLIDE_ANI;
	private Group maleGroup;
	private ImageView male1;
	private ImageView male2;
	private ImageView maleJump;
	private ImageView maleSlide;
	private int gravity=0;
	private boolean isJump;
	private Rectangle hitBox;
	
	public Male() {
		setHitBox();
		maleAnimationHandle();
		maleJumpAnimationSetup();
		maleSlideAnimationSetup();
		setSize();
		isJump=false;
	}
	
	public Rectangle getHitBox() {
		return hitBox;
	}
	
	public void maleAnimationHandle() {
		MALE_ANI = new Timeline();
		MALE_ANI.setCycleCount(Timeline.INDEFINITE);
		MALE_ANI.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			maleGroup.getChildren().setAll(male1);
		}));
		MALE_ANI.getKeyFrames().add(new KeyFrame(Duration.millis(270), (ActionEvent event) -> {
			maleGroup.getChildren().setAll(male2);
		}));
		MALE_ANI.play();
	}
	
	public void maleJumpAnimationSetup() {
		JUMP_ANI = new Timeline();
		JUMP_ANI.setCycleCount(Timeline.INDEFINITE);
		JUMP_ANI.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			maleGroup.getChildren().setAll(maleJump);
		}));
		JUMP_ANI.play();
	}
	
	public void maleSlideAnimationSetup() {
		SLIDE_ANI = new Timeline();
		SLIDE_ANI.setCycleCount(Timeline.INDEFINITE);
		SLIDE_ANI.getKeyFrames().add(new KeyFrame(Duration.millis(100), (ActionEvent event) -> {
			maleGroup.getChildren().setAll(maleSlide);
		}));
		SLIDE_ANI.play();
	}
	
	@Override
	public void setPosition() {
		// TODO Auto-generated method stub
		maleGroup.setLayoutX(100);
		maleGroup.setLayoutY(375);
	}
	
	@Override
	public void move() {
		// TODO Auto-generated method stub
		if(isJump) {
			MALE_ANI.stop();
			JUMP_ANI.play();
			SLIDE_ANI.stop();
		}
		else if(GamePlay.isPressSlide) {
			MALE_ANI.stop();
			JUMP_ANI.stop();
			SLIDE_ANI.play();
			hitBox.setLayoutY(550);
			if(!Resloader.slideSound.isPlaying())
				Resloader.slideSound.play();
		}
		else {
			MALE_ANI.play();
			JUMP_ANI.stop();
			SLIDE_ANI.stop();
			hitBox.setLayoutY(450);
		}
	}
	
	public void jump() {
		if (GamePlay.isAlive) { 
			double ypreviousPos = maleGroup.getTranslateY();
			AnimationTimer jumpTimer = new AnimationTimer(){
            @Override
            public void handle(long now) {
            	maleGroup.setTranslateY(maleGroup.getTranslateY() - 20 + gravity);
            	hitBox.setTranslateY(hitBox.getTranslateY() - 20 + gravity);
                gravity = gravity + 1;
                isJump = true;
                if(ypreviousPos == maleGroup.getTranslateY()){
                	isJump=false;
                	stop();
                    gravity = 0;
                }
                 
            
            }

        };
            jumpTimer.start();
            Resloader.jumpSound.play();
		}
	}
	
	
	public Group getMale() {
		return maleGroup;
	}
	
	public boolean isJump() {
		return isJump;
	}

	private void setHitBox() {
		hitBox = new Rectangle();
		hitBox.setWidth(75);
		hitBox.setHeight(150);
		hitBox.setLayoutX(162);
		hitBox.setLayoutY(450);
		hitBox.setFill(new ImagePattern(Resloader.buttonFree));
	}
	
	private void setSize() {
		// TODO Auto-generated method stub
	}
	
	@Override
	public void setGc() {
		// TODO Auto-generated method stub
		if(CharacterSelectionSubscene.chaSel==0){
			male1 = Resloader.male1;
			male2 = Resloader.male2;
			maleGroup = new Group(male1);
			maleJump = Resloader.malejump;
			maleSlide = Resloader.maleslide;
		}
		else {
			male1 = Resloader.female1;
			male2 = Resloader.female2;
			maleGroup = new Group(male1);
			maleJump = Resloader.femalejump;
			maleSlide = Resloader.femaleslide;
		}
	}

	@Override
	public void checkIfCollide(Hitable x) {
		// TODO Auto-generated method stub
		
	}
	
	
}
