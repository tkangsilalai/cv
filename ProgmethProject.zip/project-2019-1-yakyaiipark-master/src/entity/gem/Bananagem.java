package entity.gem;

import entity.base.Gem;
import entity.base.ThreadTimer;
import javafx.scene.paint.ImagePattern;
import resloader.Resloader;
import view.GamePlay;
import view.GameSetting;

public class Bananagem extends Gem implements ThreadTimer {
		
	private Thread Timer;
	
	public Bananagem() {
		super();
		this.getGem().setFill(new ImagePattern(Resloader.bananaGem));
	}

	@Override
	public Thread getTimer() {
		return Timer;
	}

	public void setTimer(Thread timer) {
		Timer = timer;
	}

	@Override
	public void isSkillActivated() {
		if (isActivated) {
			GamePlay.currentGemTimer = this;
			isActivated = false;
			GameSetting.gameSpeed = 10;
			System.out.println("Speedgem activated");
			int time = Gem.GEM_TIME;
			GamePlay.timerLabel.showTimerPane();
			Resloader.gemSound.play();
			GamePlay.healthBar.hp+=30;
			Timer = new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						GamePlay.timerLabel.updateTimer();
						Thread.sleep(time);
						GameSetting.gameSpeed = 5;
						GamePlay.currentGemTimer = null;
						GamePlay.timerLabel.hideTimerPane();
					} catch (InterruptedException e) {
						GameSetting.gameSpeed = 5;
						GamePlay.timerLabel.hideTimerPane();
					}
				}
			});
			Timer.start();
		}
	}

}
