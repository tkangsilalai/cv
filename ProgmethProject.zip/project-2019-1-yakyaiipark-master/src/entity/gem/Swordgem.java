package entity.gem;

import entity.Fox;
import entity.base.Gem;
import entity.base.ThreadTimer;
import javafx.scene.paint.ImagePattern;
import resloader.Resloader;
import view.GamePlay;;

public class Swordgem extends Gem implements ThreadTimer {

	Thread Timer;

	public Swordgem() {
		super();
		this.getGem().setFill(new ImagePattern(Resloader.swordGem));
	}

	@Override
	public void isSkillActivated() {
		if (isActivated) {
			GamePlay.currentGemTimer = this;
			isActivated = false;
			Fox.swordGemActivated = true;
			System.out.println("Powergem activated");
			int time = Gem.GEM_TIME;
			GamePlay.timerLabel.showTimerPane();
			Resloader.gemSound.play();
			Timer = new Thread(new Runnable() {
				@Override
				public void run() {
					try {
						GamePlay.timerLabel.updateTimer();
						Thread.sleep(time);
						Fox.swordGemActivated = false;
						GamePlay.currentGemTimer = null;
						GamePlay.timerLabel.hideTimerPane();
					} catch (InterruptedException e) {
						Fox.swordGemActivated = false;
						GamePlay.timerLabel.hideTimerPane();
					}
				}
			});
			Timer.start();
		}
	}

	@Override
	public Thread getTimer() {
		return Timer;
	}

}
