package entity;

import java.util.Random;

import entity.base.Entity;
import entity.base.Hitable;
import javafx.scene.image.ImageView;
import resloader.Resloader;
import ui.CharacterSelectionSubscene;
import ui.ScorePane;
import view.GamePlay;
import view.GameSetting;

public class Fox extends Entity implements Hitable{

	private ImageView[] foxes;
	private static int lastFoxRelocated;
	private int random;
	public static boolean swordGemActivated = false;
	private int time=0;
	private Random randomGenerator;
	public static final int REST_GAB = 1000, FOX_NUMBER = 100,FOX_Y=535;
	
	public Fox() {
		super();
		lastFoxRelocated = FOX_NUMBER - 1;
	}
	
	public ImageView[] getFoxes() {
		return foxes;
	}
	
	@Override
	public void setPosition() {
		// TODO Auto-generated method stub
		for (int i = 0; i < FOX_NUMBER; i++) {
			random = randomGenerator.nextInt(20) * 20;
			foxes[i].setLayoutX(i * REST_GAB + 1000);
		}
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		time++;
		for (int i = 0; i < foxes.length; i++) {
			foxes[i].setLayoutX(foxes[i].getLayoutX() - 2*GameSetting.gameSpeed);
			if(foxes[i].getLayoutY()==FOX_Y) {
				if(time%10==0) foxes[i].setImage(Resloader.fox2);
				else if(time%10==5) foxes[i].setImage(Resloader.fox1);
			}
			else if(foxes[i].getLayoutY()==FOX_Y-100){
				if(time%10==0) foxes[i].setImage(Resloader.bee2);
				else if(time%10==5) foxes[i].setImage(Resloader.bee1);
			}
			else {
				if(time%10==0) foxes[i].setImage(Resloader.pig2);
				else if(time%10==5) foxes[i].setImage(Resloader.pig1);
			}
			if(foxes[i].getLayoutX()==70) {
				ScorePane.score++;
				ScorePane.updateScore();
			}
		}
		checkIfOutOfBorder();
		hitBySwordGem(GamePlay.MALE, swordGemActivated);
		checkIfCollide(GamePlay.MALE);
	}
	
	public void hitBySwordGem(Hitable malez, boolean x) {
		Male male = (Male) malez;
		if (x) {
			for (int i = 0; i < FOX_NUMBER; i++) {
				if ((foxes[i].getBoundsInParent().intersects(male.getMale().getBoundsInParent()))) {
					foxes[i].setLayoutY(GameSetting.GAME_HEIGHT * 2);
				}
			}
		}
	}
	
	public void reLocate(int i) {
		foxes[i].setLayoutX(foxes[lastFoxRelocated].getLayoutX() + REST_GAB + foxes[i].getFitWidth());
		foxes[i].setLayoutY(FOX_Y);
		lastFoxRelocated = i;
		if (i%10 == 8) {
			int xx = randomGenerator.nextInt(GamePlay.gem.length);
			GamePlay.gem[xx].calledAt(1200,400);
		}
	}
	
	public void checkIfOutOfBorder() {
		for (int i = 0; i < FOX_NUMBER; i++) {
			random = randomGenerator.nextInt(20) * 20;
			if (foxes[i].getLayoutX() < foxes[i].getFitWidth()-100) {
				reLocate(i);
			}
		}
	}
	@Override
	public void setGc() {
		// TODO Auto-generated method stub
		randomGenerator = new Random();
		foxes = new ImageView[FOX_NUMBER];
		for (int i = 0; i < FOX_NUMBER; i++) {
			random = randomGenerator.nextInt(100);
			if(random%3==0) {
				foxes[i] = new ImageView(Resloader.fox1);
				foxes[i].setLayoutY(FOX_Y);
			}
			else if(random%3==1){
				foxes[i] = new ImageView(Resloader.bee1);
				foxes[i].setLayoutY(FOX_Y-100);
			}
			else {
				foxes[i] = new ImageView(Resloader.pig1);
				foxes[i].setLayoutY(FOX_Y+23);
			}
		}
		
	}
	@Override
	public void checkIfCollide(Hitable x) {
		// TODO Auto-generated method stub
		Male male = (Male) x;
		for (int i = 0; i < FOX_NUMBER; i++) {
			if (foxes[i].getBoundsInParent().intersects(male.getHitBox().getBoundsInParent())) {
				if(CharacterSelectionSubscene.chaSel==0) {
					if(!Resloader.deadSoundMale.isPlaying()) {
						Resloader.deadSoundMale.play();
						GamePlay.healthBar.hp-=50;
					}
				}
				else {
					if(!Resloader.deadSoundFemale.isPlaying()) {
						Resloader.deadSoundFemale.play();
						GamePlay.healthBar.hp-=50;
					}
				}
			}
		}
	}	
}