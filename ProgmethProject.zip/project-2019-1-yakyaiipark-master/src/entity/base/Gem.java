package entity.base;

import entity.Male;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import view.GamePlay;
import view.GameSetting;

public abstract class Gem extends Entity implements Hitable {

	private static final int GEM_HEIGHT = 80;
	private Rectangle gem;
	private boolean isCalled;
	public boolean isActivated;
	public static final int GEM_TIME = 5000;

	public Gem() {
		super();
		isCalled = false;
		isActivated = false;
	}

	public Rectangle getGem() {
		return gem;
	}

	@Override
	public void setPosition() {
		gem.setLayoutX(-GameSetting.GAMEPLAY_HEIGHT);
		gem.setLayoutY(-GameSetting.GAME_WIDTH);
	}

	public void checkIfOutOfBorder() {
		if (gem.getLayoutX() < -gem.getWidth()) {
			reLocate();
		}
	}

	public void reLocate() {
		this.setPosition();
	}

	@Override
	public void move() {
		if (isCalled) {
			gem.setLayoutX(gem.getLayoutX() - GameSetting.gameSpeed);
			checkIfCollide(GamePlay.MALE);
		}
	}

	@Override
	public void setGc() {
		gem = new Rectangle();
		gem = new Rectangle(GEM_HEIGHT, GEM_HEIGHT, Color.BLACK);
	}

	public void calledAt(int posx, int posy) {
		gem.setLayoutX(posx);
		gem.setLayoutY(posy);
		isCalled = true;
	}

	@Override
	public void checkIfCollide(Hitable x) {
		Male male = (Male) x;
		if ((gem.getBoundsInParent().intersects(male.getHitBox().getBoundsInParent()))) {
			reLocate();
			isActivated = true;
		}
	}

	public boolean isActivated() {
		return isActivated;
	}

	public abstract void isSkillActivated();

}
