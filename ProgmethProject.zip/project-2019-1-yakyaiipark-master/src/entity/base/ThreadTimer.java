package entity.base;

public interface ThreadTimer {

	public Thread getTimer();

}
