package entity.base;

public interface Hitable {

	public void checkIfCollide(Hitable x);
}
