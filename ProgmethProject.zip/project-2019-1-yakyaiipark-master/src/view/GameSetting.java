package view;

public class GameSetting {
	public static final int GAME_WIDTH = 1200, GAME_HEIGHT = 500, GAMEPLAY_HEIGHT = 800;
	public static int gameSpeed = 5;
}
