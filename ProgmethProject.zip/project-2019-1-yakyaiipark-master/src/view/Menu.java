package view;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import resloader.Resloader;
import view.GameSetting;
import ui.CharacterSelectionSubscene;
import ui.HowtoplaySubscene;
import ui.MenuButtons;

public class Menu {

	public static Stage mainStage;
	private AnchorPane mainPane;
	private HBox buttonsPane;
	private HowtoplaySubscene howtoplaySubscene;
	private CharacterSelectionSubscene chaSel;

	public Menu() {
		// TODO Auto-generated constructor stub
		Resloader.Load();
		mainStage = new Stage();
		mainPane = new AnchorPane();
		Scene scene = new Scene(mainPane,GameSetting.GAME_WIDTH,GameSetting.GAME_HEIGHT);
		mainStage.setTitle("Safari Run");
		mainStage.setScene(scene);
		createBackground();
		createLogo();
		createButtons();
		createHowtoplaySubscene();
		createChaSelSubscene();
		createBackgroundSound();
		playBackgroundSound();
	}
	
	//background
	private void createBackground() {
		BackgroundImage background = new BackgroundImage(Resloader.bgMenuImg, BackgroundRepeat.NO_REPEAT,
				BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, null);
		mainPane.setBackground(new Background(background));
	}
	
	//logo
	private void createLogo() {
		ImageView logoImg = Resloader.logoImg;
		logoImg.setPreserveRatio(true);
		logoImg.setLayoutX(40);
		logoImg.setLayoutY(-40);
		mainPane.getChildren().add(logoImg);
	}
	
	//buttons
	private void createButtons() {
		buttonsPane = new HBox(40);
		buttonsPane.setLayoutX(340);
		buttonsPane.setLayoutY(280);
		buttonsPane.getChildren().addAll(createHowToPlayButton(), createPlayButton(), createExitButton());
		mainPane.getChildren().add(buttonsPane);
	}
	
	//sound
	private void createBackgroundSound() {
		Resloader.backgroundGameSound.setOnEndOfMedia(new Runnable() {
			@Override
			public void run() {
				Resloader.backgroundGameSound.seek(javafx.util.Duration.ZERO);
			}
		});
	}
	
	public static void playBackgroundSound() {
		Resloader.backgroundGameSound.play();
	}
	
	public static void stopBackgroundSound() {
		Resloader.backgroundGameSound.stop();
	}
	
	private MenuButtons createPlayButton() {
		MenuButtons button = new MenuButtons("PLAY");
		button.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				//GamePlay game = new GamePlay();
				chaSel.enter();
				System.out.println("Play");
				//game.createNewGame();
			}
		});
		return button;
	}
	
	private MenuButtons createHowToPlayButton() {
		MenuButtons button = new MenuButtons("HOW TO PLAY");
		button.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				howtoplaySubscene.enter();
				System.out.println("How To play");
			}
		});
		return button;
	}
	
	private MenuButtons createExitButton() {
		MenuButtons button = new MenuButtons("EXIT");
		button.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				System.exit(0);
			}
		});
		return button;
	}
	
	//how to play subscene
	private void createHowtoplaySubscene() {
		howtoplaySubscene = new HowtoplaySubscene();
		mainPane.getChildren().add(howtoplaySubscene);
	}
	
	private void createChaSelSubscene() {
		chaSel = new CharacterSelectionSubscene();
		mainPane.getChildren().add(chaSel);
	}
	
}
