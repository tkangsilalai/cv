package view;


import entity.Fox;
import entity.Male;
import entity.base.Gem;
import entity.base.ThreadTimer;
import entity.gem.Applegem;
import entity.gem.Bananagem;
import entity.gem.Swordgem;
import javafx.animation.AnimationTimer;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import resloader.Resloader;
import ui.BackgroudPane;
import ui.CharacterSelectionSubscene;
import ui.DeadSubscene;
import ui.HealthBarPane;
import ui.ScorePane;
import ui.TimerPane;


public class GamePlay {
	
	private AnchorPane gamePane;
	private Scene gameScene;
	private BackgroudPane bg;
	private Fox fox;
	public static Stage gameStage;
	public static TimerPane timerLabel;
	public static ScorePane scoreLabel;
	public static HealthBarPane healthBar;
	public static AnimationTimer GAMETIMER;
	public static Male MALE;
	public static Gem[] gem;
	public static boolean isPressJump, isPressSlide, isAlive, triggered;
	public static ThreadTimer currentGemTimer;
	
	public GamePlay() {
		InitializeStage();
		createKeyListener();
	}
	private void InitializeStage() {
		gamePane = new AnchorPane();
		gameScene = new Scene(gamePane, GameSetting.GAME_WIDTH, GameSetting.GAMEPLAY_HEIGHT);
		gameStage = new Stage();
		gameStage.setTitle("Safari Run");
		gameStage.setScene(gameScene);
	}
	
	private void createKeyListener() {
		gameScene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) { 
				if (event.getCode() == KeyCode.UP && triggered == false && !MALE.isJump()) {
					triggered = true;
					isPressJump = true;
					MALE.jump();
				}
				if (event.getCode() == KeyCode.DOWN && !MALE.isJump()) {
					triggered = true;
					isPressSlide = true;
				}
			}
		});
		gameScene.setOnKeyReleased(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				isPressJump = false;
				isPressSlide = false;
				triggered = false;
			}
		});
	}
	
	public void createNewGame() {
		Menu.mainStage.hide();
		Menu.stopBackgroundSound();
		Resloader.Load();
		createGameEntities();
		createGameUi();
		createGameLoop();
		isAlive = true;
		isPressJump = false;
		isPressSlide = false;
		triggered = false;
		gameStage.show();
	}
	
	private void createGameUi() {
		// Initialize scorePane
		scoreLabel = new ScorePane();
		gamePane.getChildren().add(scoreLabel.getscoreLabel());
		
		// Initialize timerPane
		timerLabel = new TimerPane();
		gamePane.getChildren().add(timerLabel.getTimerLabel());
		
		//health bar pane
		healthBar = new HealthBarPane();
		healthBar.setLayoutX(GameSetting.GAME_WIDTH-335);
		//healthBar.getHealth().setLayoutX(GameSetting.GAME_WIDTH-300);
		gamePane.getChildren().add(healthBar);
	}
	
	private void createGameEntities() {
		//Initialize backGrouds
		bg = new BackgroudPane();
		gamePane.getChildren().add(bg.getRect()[0]);
		gamePane.getChildren().add(bg.getRect()[1]);
		
		//Initialize male
		MALE = new Male();
		gamePane.getChildren().add(MALE.getMale());
		//gamePane.getChildren().add(MALE.getHitBox());
		
		//Initialize foxes
		fox = new Fox();
		for (int i = 0; i < Fox.FOX_NUMBER; i++) {
			gamePane.getChildren().addAll(fox.getFoxes()[i]);
		}
		
		// Initialize Gems
		gem = new Gem[3];
		gem[0] = (Gem) new Applegem();
		gem[1] = (Gem) new Swordgem();
		gem[2] = (Gem) new Bananagem();
		for (Gem x : gem) {
			gamePane.getChildren().add(x.getGem());
		}
	}
	
	private void createGameLoop() {
		GAMETIMER = new AnimationTimer() {
			@Override
			public void handle(long now) {
				if (isAlive == false) {
					Dead();
				} else {
					fox.move();
					MALE.move();
					bg.move();
					healthBar.work();
					for (Gem x : gem) {
						x.move();
						x.isSkillActivated();
					}

				}
			}
		};
		GAMETIMER.start();
	}
	
	private void Dead() {
		Resloader.lose.play();
		GamePlay.GAMETIMER.stop();
		Male.MALE_ANI.stop();
		ScorePane.updateHighScore();
		gamePane.getChildren().removeAll(scoreLabel.getscoreLabel(), timerLabel.getTimerLabel());
		DeadSubscene deadSubscene = new DeadSubscene();
		deadSubscene.enter();
		gamePane.getChildren().addAll(deadSubscene);
		try {
			if (currentGemTimer != null) {
				currentGemTimer.getTimer().interrupt();
				timerLabel.getTimer().interrupt();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
