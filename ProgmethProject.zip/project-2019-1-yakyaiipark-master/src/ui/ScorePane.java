package ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.text.Font;

public class ScorePane {

	private static Label scoreLabel;
	public static int score;
	public static int highestScore = 0;

	public ScorePane() {
		scoreLabel = new Label();
		score = 0;
		scoreLabel.setPrefHeight(800);
		scoreLabel.setPrefWidth(400);
		scoreLabel.setFont(Font.loadFont(ClassLoader.getSystemResource("Classique-Saigon.ttf").toString(),64));
		scoreLabel.setAlignment(Pos.TOP_LEFT);
		scoreLabel.setPadding(new Insets(10, 10, 10, 10));
		scoreLabel.setText("score : 00");
	}

	public static void updateScore() {
		String textToSet = "score : ";
		if (score < 10) {
			textToSet = textToSet + "0";
		}
		scoreLabel.setText(textToSet + score);
	}

	public static void updateHighScore() {
		if (score > highestScore) {
			highestScore = score;
		}
	}

	public Label getscoreLabel() {
		return scoreLabel;
	}

	public static void setscore(int score) {
		ScorePane.score = score;
	}
	
}
