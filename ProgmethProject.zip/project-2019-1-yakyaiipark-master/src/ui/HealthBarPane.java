package ui;

import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import resloader.Resloader;
import view.GamePlay;

public class HealthBarPane extends AnchorPane{
	
	private ImageView health;
	private Label hpText;
	public int hp;
	private int time;
	
	public HealthBarPane() {
		hp=100;
		time=0;
		health= new ImageView(Resloader.health100);
		hpText = new Label(this.hp+"/100");
		hpText.setLayoutY(15);
		hpText.setLayoutX(10);
		hpText.setFont(Font.loadFont(ClassLoader.getSystemResource("Classique-Saigon.ttf").toString(),32));
		this.getChildren().addAll(health,hpText);
	}
	
	public void work() {
		time++;
		if(time%50==0) {
			hp--;
		}
		if(hp>100) hp=100;
		if(hp<0) hp=0;
		if(hp>90) {
			health.setImage(Resloader.health100);
		}
		else if(hp<=90 && hp>80) {
			health.setImage(Resloader.health90);
		}
		else if(hp<=80 && hp>70) {
			health.setImage(Resloader.health80);
		}
		else if(hp<=70 && hp>60) {
			health.setImage(Resloader.health70);
		}
		else if(hp<=60 && hp>50) {
			health.setImage(Resloader.health60);
		}
		else if(hp<=50 && hp>40) {
			health.setImage(Resloader.health50);
		}
		else if(hp<=40 && hp>30) {
			health.setImage(Resloader.health40);
		}
		else if(hp<=30 && hp>20) {
			health.setImage(Resloader.health30);
		}
		else if(hp<=20 && hp>10) {
			health.setImage(Resloader.health20);
		}
		else if(hp<=10 && hp>0){
			health.setImage(Resloader.health10);
		}
		else if(hp==0) {
			health.setImage(Resloader.health0);
		}
		this.hpText.setText(this.hp+"/100");
		try {
			checkHp();
		} catch (HpRunOutException e) {
			GamePlay.isAlive = false;
		}
	}

	public void checkHp() throws HpRunOutException {
		if (GamePlay.healthBar.hp==0) {
			throw new HpRunOutException("Run out of HP!!");
		}
	}
	
	
}