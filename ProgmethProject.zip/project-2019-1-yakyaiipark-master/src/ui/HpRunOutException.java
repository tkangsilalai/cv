package ui;
@SuppressWarnings("serial")
public class HpRunOutException extends Exception{		
	
	public HpRunOutException(String e) {
		super(e);
	}
}

