package ui.base;

import javafx.scene.SubScene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import resloader.Resloader;
import view.GameSetting;

public abstract class GameSubscene extends SubScene{
	
	protected boolean isHidden;

	public GameSubscene() {
		super(new AnchorPane(), 550, 400);
		// TODO Auto-generated constructor stub
		Resloader.Load();
		AnchorPane pane = (AnchorPane) this.getRoot();
		BackgroundImage background = new BackgroundImage(Resloader.subSceneBg, BackgroundRepeat.NO_REPEAT,
				BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, null);
		pane.setBackground(new Background(background));
		isHidden = true;
		setLayoutX(GameSetting.GAME_WIDTH);
		setLayoutY(80);
	}
	
	protected abstract void enter();
	
	protected AnchorPane getPane() {
		return (AnchorPane) this.getRoot();
	}
	
}
