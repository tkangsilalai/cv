package ui;

import javafx.animation.TranslateTransition;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.util.Duration;
import ui.base.GameSubscene;

public class HowtoplaySubscene extends GameSubscene{

	public HowtoplaySubscene() {
		// TODO Auto-generated constructor stub
		Label label = new Label("HOW TO PLAY");
		label.setFont(Font.loadFont(ClassLoader.getSystemResource("Classique-Saigon.ttf").toString(),64));
		label.setLayoutX(85);
		label.setLayoutY(25);
		Label description = new Label("    press Up to jump \n  press Down to slide \n   avoid the animals!!.");
		description.setLayoutX(105);
		description.setLayoutY(150);
		description.setFont(Font.loadFont(ClassLoader.getSystemResource("Classique-Saigon.ttf").toString(),32));
		this.getPane().getChildren().addAll(label,description);
	}
	
	public void enter() {
		TranslateTransition transition = new TranslateTransition();
		transition.setDuration(Duration.seconds(0.3));
		transition.setNode(this);
		if (isHidden) {
			transition.setToX(-600);
			isHidden = false;
		} else {
			transition.setToX(1000);
			isHidden = true;
		}
		transition.play();
	}
	
}
