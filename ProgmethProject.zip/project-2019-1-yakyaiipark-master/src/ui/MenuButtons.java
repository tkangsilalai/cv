package ui;

import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.text.Font;
import resloader.Resloader;

public class MenuButtons extends Button{
	
	private static final int BUTTON_HEIGHT = 50;
	private static final int BUTTON_WIDTH = 150;

	public MenuButtons(String text) {
		Resloader.Load();
		setText(text);
		setPrefWidth(BUTTON_WIDTH);
		setPrefHeight(BUTTON_HEIGHT);
		setButtonFree();
		initializeButton();
		setFont(Font.loadFont(ClassLoader.getSystemResource("Classique-Saigon.ttf").toString(),18));
		
	}

	private void setButtonPressedStyle() {
		BackgroundImage background = new BackgroundImage(Resloader.buttonPressed, BackgroundRepeat.NO_REPEAT,
				BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, null);
		setBackground(new Background(background));
		setPrefHeight(45);
		setLayoutY(getLayoutY() + 4);
	}

	private void setButtonFree() {
		BackgroundImage background = new BackgroundImage(Resloader.buttonFree, BackgroundRepeat.NO_REPEAT,
				BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, null);
		setBackground(new Background(background));
		setPrefHeight(49);
		setLayoutY(getLayoutY() - 4);
	}

	private void initializeButton() {

		setOnMousePressed(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if (event.getButton().equals(MouseButton.PRIMARY)) {
					setButtonPressedStyle();
				}
			}
		});

		setOnMouseReleased(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				if (event.getButton().equals(MouseButton.PRIMARY)) {
					setButtonFree();
				}
			}
		});

		setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				setEffect(new DropShadow());
			}
		});

		setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				setEffect(null);
			}
		});
	}
}
