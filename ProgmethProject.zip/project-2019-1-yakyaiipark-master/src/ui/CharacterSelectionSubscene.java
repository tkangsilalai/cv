package ui;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.util.Duration;
import resloader.Resloader;
import ui.base.GameSubscene;
import view.GamePlay;

public class CharacterSelectionSubscene extends GameSubscene{
	
	public static int chaSel;
	
	public CharacterSelectionSubscene() {
		// TODO Auto-generated constructor stub
		Label label = new Label("Select Character");
		label.setFont(Font.loadFont(ClassLoader.getSystemResource("Classique-Saigon.ttf").toString(),64));
		label.setLayoutX(25);
		label.setLayoutY(25);
		VBox male = new VBox();
		MenuButtons mbutt = new MenuButtons("MALE");
		mbutt.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				GamePlay game = new GamePlay();
				chaSel=0;
				System.out.println("Play");
				game.createNewGame();
			}
		});
		male.getChildren().addAll(Resloader.malejump, mbutt);
		male.setLayoutX(75);
		male.setLayoutY(65);
		VBox female = new VBox();
		MenuButtons fmbutt = new MenuButtons("FEMALE");
		fmbutt.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				GamePlay game = new GamePlay();
				chaSel=1;
				System.out.println("Play");
				game.createNewGame();
			}
		});
		female.getChildren().addAll(Resloader.femalejump, fmbutt);
		female.setLayoutX(300);
		female.setLayoutY(65);
		this.getPane().getChildren().addAll(label,male,female);
	}

	@Override
	public void enter() {
		// TODO Auto-generated method stub
		TranslateTransition transition = new TranslateTransition();
		transition.setDuration(Duration.seconds(0.3));
		transition.setNode(this);
		if (isHidden) {
			transition.setToX(-600);
			isHidden = false;
		} else {
			transition.setToX(1000);
			isHidden = true;
		}
		transition.play();
	}
	
}
