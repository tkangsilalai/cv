package ui;

import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.text.Font;
import javafx.util.Duration;
import ui.base.GameSubscene;
import view.GamePlay;
import view.Menu;

public class DeadSubscene extends GameSubscene{
	
	public DeadSubscene() {
		Label label = new Label("GameOver");
		label.setFont(Font.loadFont(ClassLoader.getSystemResource("Classique-Saigon.ttf").toString(),64));
		label.setLayoutX(135);
		label.setLayoutY(115);
		Button backButton = createBackbutton();
		backButton.setLayoutX(55);
		backButton.setLayoutY(300);
		Button retryButton = createRetrybutton();
		retryButton.setLayoutX(335);
		retryButton.setLayoutY(300);
		this.getPane().getChildren().addAll(label,backButton,retryButton);
		this.createCurrentScoreLabel();
		this.createHighestScoreLabel();
	}

	private MenuButtons createBackbutton() {
		MenuButtons backButton = new MenuButtons("BACK");
		backButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				GamePlay.gameStage.close();
				Menu.mainStage.show();
				//Menu.playBackgroundSound();
			}
		});
		return backButton;
	}

	private MenuButtons createRetrybutton() {
		MenuButtons retryButton = new MenuButtons("TRY AGAIN!!!");
		retryButton.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				GamePlay.gameStage.close();
				GamePlay game = new GamePlay();
				System.out.println("Retry.");
				game.createNewGame();
			}
		});
		return retryButton;
	}
	@Override
	public void enter() {
		// TODO Auto-generated method stub
		TranslateTransition transition = new TranslateTransition();
		transition.setDuration(Duration.seconds(0.3));
		transition.setNode(this);
		if (isHidden) {
			transition.setToX(-880);
			isHidden = false;
		} else {
			transition.setToX(1000);
			isHidden = true;
		}
		transition.play();
	}
	
	private void createHighestScoreLabel() {
		Label highestScoreLabel = new Label("HIGH SCORE: " + String.valueOf(ScorePane.highestScore));
		highestScoreLabel.setLayoutX(55);
		highestScoreLabel.setLayoutY(250);
		highestScoreLabel.setFont(Font.loadFont(ClassLoader.getSystemResource("Classique-Saigon.ttf").toString(),32));
		this.getPane().getChildren().addAll(highestScoreLabel);
	}

	private void createCurrentScoreLabel() {
		Label scoreLabel = new Label("SCORE: " + String.valueOf(ScorePane.score));
		scoreLabel.setLayoutX(335);
		scoreLabel.setLayoutY(250);
		scoreLabel.setFont(Font.loadFont(ClassLoader.getSystemResource("Classique-Saigon.ttf").toString(),32));
		this.getPane().getChildren().addAll(scoreLabel);
	}

}
